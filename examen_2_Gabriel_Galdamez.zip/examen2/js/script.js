// Inicializa Fancybox para la galería de productos
document.addEventListener("DOMContentLoaded", function () {
	if (window.Fancybox) {
		Fancybox.bind('[data-fancybox="productos"]', {
			Toolbar: {
				display: ["close"]
			}
		});
	}
});
